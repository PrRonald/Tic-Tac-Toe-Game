export default function Square() {
  return <button className="square">X</button>;
}
